import os, gc
import numpy as np
import datatable as dtable
import pandas as pd
# import janestreet
import matplotlib.pyplot as plt
import xgboost as xgb

from sklearn.metrics import roc_auc_score, roc_curve
from sklearn.model_selection import GroupKFold
from matplotlib.colors import ListedColormap
from tqdm import tqdm
from joblib import dump, load
from numba import njit
from utils import PurgedGroupTimeSeriesSplit
from configuration import get_config
from plotting import plot_cv_indices

@njit
def fast_fillna(array, values):
    if np.isnan(array.sum()):
        array = np.where(np.isnan(array), values, array)
    return array

if __name__ == "__main__":

    m_args = get_config("JANESTREET")

    print('Loading data...')
    train = dtable.fread(os.path.join(m_args.data_path, 'train.csv')).to_pandas()
    features = [c for c in train.columns if 'feature' in c]

    print('Filling data...')
    train = train.query('weight > 0').reset_index(drop = True)
    train[features] = train[features].fillna(method = 'ffill').fillna(0)

    resp_cols = ['resp_1', 'resp_2', 'resp_3', 'resp', 'resp_4']
    y = np.mean(train[resp_cols], 1)
    y = np.where(y >= 0, 1, 0).astype(int)
    y = y.reshape((y.shape[0],1))
    train['action'] = y

    fig, ax = plt.subplots()
    cv = PurgedGroupTimeSeriesSplit(n_splits = m_args.n_splits, group_gap = m_args.group_gap)
    plot_cv_indices(cv, train[features].values, train['action'].values, train['date'].values, ax, 5, lw = 20)
    plt.show()

    p_best = {'learning_rate': 0.014106988708201764,
          'max_depth': 8, 
          'gamma': 9.800749651802157, 
          'min_child_weight': 0.3032862674190433, 
          'subsample': 0.4648851101943981, 
          'colsample_bytree': 0.994909039539885, 
          'objective': 'binary:logistic',
          'eval_metric': 'auc', 
        #   'tree_method': 'gpu_hist', 
         }

    X_tr, y_tr = train.loc[train['date'] > 85, features].values, train.loc[train['date'] > 85, 'action'].values
    d_tr = xgb.DMatrix(X_tr, y_tr)

    # Seed Blending
    models = []
    for seed in range(5):
        p_best['random_state'] = seed
        clf = xgb.train(p_best, d_tr, 950)
        models.append(clf)
        
        rubbish = gc.collect()
    
    
    example_test = pd.read_csv(os.path.join(m_args.data_path, 'example_test.csv'))
    example_test = example_test.query('weight > 0').reset_index(drop = True)
    example_test[features] = example_test[features].fillna(method = 'ffill').fillna(0)
    d_tt = xgb.DMatrix(example_test[features].values)
    test_preds = np.zeros(example_test.shape[0])
    for clf in models:
        test_preds += clf.predict(d_tt) / len(models)
    print(test_preds.min())
    print(test_preds.max())
    print(test_preds.mean())
    print(test_preds.std())
    plt.hist(test_preds, bins = 100)
    plt.show()

    """
    Submission on kaggle
    please uncomment the prediction
    """
    train.loc[0, features[1:]] = fast_fillna(train.loc[0, features[1:]].values, 0)

    # env = janestreet.make_env()
    # env_iter = env.iter_test()

    # opt_th = 0.505
    # tmp = np.zeros(len(features))
    # for (test_df, pred_df) in tqdm(env_iter):
    #     if test_df['weight'].item() > 0:
    #         x_tt = test_df.loc[:, features].values
    #         x_tt[0, :] = fast_fillna(x_tt[0, :], tmp)
    #         tmp = x_tt[0, :]
    #         d_tt = xgb.DMatrix(x_tt)
    #         pred = 0.
    #         for clf in models:
    #             pred += clf.predict(d_tt) / len(models)
    #         pred_df.action = np.where(pred >= opt_th, 1, 0).astype(int)
    #     else:
    #         pred_df.action = 0
    #     env.predict(pred_df)