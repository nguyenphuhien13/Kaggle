# Jane Street 9th place

### Preprocess data

Configuration for training model includes data_path, n_plits and group_gap 

```text
JANESTREET:
  data_path: jane-street-market-prediction 
  n_splits: 5
  group_gap: 20
```

- To run training and inference, simply run submission.py

**Note**
Please install janestreet environment, uncomment import and inference code for a complete run